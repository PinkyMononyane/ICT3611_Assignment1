﻿Imports System.IO
Imports Microsoft.VisualBasic

Public Class Managing_Motor_Racing


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles SaveButton.Click
        Dim writer As TextWriter = New StreamWriter("F:\MYAPPFILES\FILE.txt")
        writer.Write(EventTitle.Text + (","))
        writer.Write(EventDate.Value.ToString + (","))
        writer.Write(ListTextBox.Text + (","))
        writer.Write(RegistrationFee.Text + (","))
        writer.Write(EventLocation.Text + (","))

        writer.Close()
        MessageBox.Show("Data Stored Successfully")
    End Sub

    Private Sub ViewMembersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewMembersToolStripMenuItem.Click
        Search_Form.Show()

        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles AddButton.Click
        Management_Of_Racing_Drivers.Show()
        Me.Hide()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles DisplayButton.Click
        ListTextBox.AppendText(" " + vbNewLine)
        ListTextBox.AppendText(vbTab & Label1.Text + " : " + EventTitle.Text + vbNewLine)
        ListTextBox.AppendText("===========================================" + vbNewLine)
        ListTextBox.AppendText(vbTab & Label2.Text + " : " + EventDate.Text + vbNewLine)
        ListTextBox.AppendText("===========================================" + vbNewLine)
        ListTextBox.AppendText(vbTab & Label3.Text + " : " + RegistrationFee.Text + vbNewLine)
        ListTextBox.AppendText(" " + vbNewLine)
        ListTextBox.AppendText(vbTab & Label4.Text + " : " + EventLocation.Text + vbNewLine)
        ListTextBox.AppendText(" " + vbNewLine)
        ListTextBox.AppendText(vbTab & Label5.Text + " : " + NumberOfLaps.Text + vbNewLine)
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles NumberOfLaps.TextChanged
        If IsNumeric(NumberOfLaps.Text) Then

            'Do What u wanna do here 
        Else

            NumberOfLaps.Text = ""
            MessageBox.Show("You can only input number")
        End If
    End Sub

    Private Sub AddNewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddNewToolStripMenuItem.Click
        Management_Of_Racing_Drivers.Show()
        Me.Hide()
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles RegistrationFee.TextChanged
        If IsNumeric(RegistrationFee.Text) Then

            'Do What u wanna do here 
        Else

            NumberOfLaps.Text = ""
            MessageBox.Show("You can only input number")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles RemoeButton.Click
        EventTitle.ResetText()
        EventDate.ResetText()
        RegistrationFee.ResetText()
        EventLocation.ResetText()
        NumberOfLaps.ResetText()
        ListTextBox.ResetText()

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub ListTextBox_TextChanged(sender As Object, e As EventArgs) Handles ListTextBox.TextChanged

    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Search_Form.Show()
        Me.Hide()
    End Sub
End Class
