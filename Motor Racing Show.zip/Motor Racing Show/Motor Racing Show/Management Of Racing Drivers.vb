﻿Imports System.IO

Public Class Management_Of_Racing_Drivers

    Dim path As String = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
    Dim FILE_NAME As String = "D:\MyAPPLICTION FILE\DataFile.txt"

    Dim yearJoined As String
    Dim yearOfBirth As String


    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        Me.Close()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click


        'MessageBox.Show(FILE_NAME)

        Dim stringReader As String
        ' stringReader = fileReader.ReadLine()
        ' MsgBox("The first line of the file is " & stringReader)


        If My.Computer.FileSystem.FileExists(FILE_NAME) Then


            Dim fileReader As System.IO.StreamReader
            fileReader = My.Computer.FileSystem.OpenTextFileReader(FILE_NAME)
            stringReader = File.ReadAllText(FILE_NAME)
            fileReader.Close()
            '   MessageBox.Show(stringReader)

            If stringReader.Contains(Trim(Member_Number.Text)) Then
                MessageBox.Show("Memebr Already Exist!")

            Else
                Dim writer As TextWriter = New StreamWriter(FILE_NAME, True)
                writer.Write(Member_Number.Text + (" , "))
                writer.Write(Name_Surname.Text + (" , "))
                writer.Write(BirthDate.Value.ToString + ("  ,"))
                Dim gender As String
                If Female.Checked = True Then
                    gender = "Female"

                ElseIf Male.Checked = True Then
                    gender = "Male"
                Else
                    gender = "Not Specified"
                End If


                writer.Write(gender + (" , "))
                writer.Write(JoinedDate.Value.ToString + (" , "))
                writer.Write(OutstandingAmount.Text + (" , "))
                writer.Write(Completed.Text + vbCrLf)


                writer.Close()
                MessageBox.Show("Data Stored")

            End If

        Else
            Dim fs As FileStream = File.Create(FILE_NAME)

            fs.Close()

            Dim writer As TextWriter = New StreamWriter(FILE_NAME, True)
            writer.Write(Member_Number.Text + (" , "))
            writer.Write(Name_Surname.Text + (" , "))
            writer.Write(BirthDate.Value.ToString + ("  ,"))
            Dim gender As String
            If Female.Checked = True Then
                gender = "Female"

            ElseIf Male.Checked = True Then
                gender = "Male"
            Else
                gender = "Not Specified"
            End If


            writer.Write(gender + (" , "))
            writer.Write(JoinedDate.Value.ToString + (" , "))
            writer.Write(OutstandingAmount.Text + (" , "))
            writer.Write(Completed.Text + vbCrLf)


            writer.Close()
            MessageBox.Show("Data Stored")

        End If


    End Sub

    Private Sub Management_Of_Racing_Drivers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        yearJoined = Date.Today.ToString("yyy")

        Member_Number.Text = yearJoined




    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Name_Surname.Clear()
        Completed.Clear()
        OutstandingAmount.Clear()
        Member_Number.Clear()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles Member_Number.TextChanged

        If Member_Number.Text.Length > 1 Then
            If IsNumeric(Member_Number.Text) Then

                'Do What u wanna do here 
            Else

                OutstandingAmount.Text = ""
                MessageBox.Show("You can only input number")
            End If

        End If
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles OutstandingAmount.TextChanged

        If OutstandingAmount.Text.Length > 1 Then
            If IsNumeric(OutstandingAmount.Text) Then

                If IsNumeric(OutstandingAmount.Text) Then

                    'Do What u wanna do here 
                Else

                    OutstandingAmount.Text = ""
                    MessageBox.Show("You can only input number")
                End If
            End If

        End If

    End Sub
    Private Sub BtnRemove_Click(sender As Object, e As EventArgs) Handles BtnRemove.Click
        Member_Number.ResetText()
        Name_Surname.ResetText()
        OutstandingAmount.ResetText()
        Completed.ResetText()
        Female.Checked = False
        Male.Checked = False



    End Sub

    Private Sub BirthDate_ValueChanged(sender As Object, e As EventArgs) Handles BirthDate.ValueChanged
        yearOfBirth = BirthDate.Value.ToString("yyy")
        Member_Number.ResetText()

        Member_Number.Text = yearJoined + yearOfBirth



    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnBack.Click
        Managing_Motor_Racing.Show()
        Me.Close()
    End Sub
End Class