﻿Imports System.IO
Imports System.Text


Public Class Search_Form
    Dim FILE_NAME As String = "D:\MyAPPLICTION FILE\DataFile.txt"


    Dim Stringreader As String


    Private Sub Search_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If My.Computer.FileSystem.FileExists(FILE_NAME) = False Then
            MessageBox.Show("DATABASE DOES NOT EXIST")
        Else

        End If
    End Sub

    Private Sub SearchTextBox2_TextChanged(sender As Object, e As EventArgs) Handles SearchTextBox.TextChanged

    End Sub

    Private Sub SearchTextBox1_TextChanged(sender As Object, e As EventArgs) Handles SearchTextBox1.TextChanged
        If SearchTextBox1.Text.Length > 12 Then
            SearchTextBox.Text = ""
            If My.Computer.FileSystem.FileExists(FILE_NAME) = False Then
                MessageBox.Show("DATABASE DOES NOT EXIST")
            Else

                Dim fileReader As System.IO.StreamReader

                fileReader = My.Computer.FileSystem.OpenTextFileReader(FILE_NAME)
                Stringreader = File.ReadAllText(FILE_NAME)
                fileReader.Close()

            End If
            If Stringreader.Contains(SearchTextBox1.Text) Then
                Result.Text = " RESULT FOUND "
                Found.Show()
                NOT_FOUD.Hide()

                Dim count As Integer = 1

                Dim fileReader As System.IO.StreamReader
                fileReader = My.Computer.FileSystem.OpenTextFileReader(FILE_NAME)
                Dim stringReader As String

                While Not fileReader.EndOfStream

                    stringReader = fileReader.ReadLine()
                    If stringReader.Contains(SearchTextBox1.Text) Then
                        '  MsgBox("Search Results " & stringReader)

                        Dim s As String = stringReader
                        Dim words As String() = s.Split(New Char() {","c})
                        Dim word As String
                        For Each word In words
                            Select Case count
                                Case 1
                                    SearchTextBox.Text += "Member ID : " + word + vbCrLf
                                Case 2
                                    SearchTextBox.Text += "Member Name : " + word + vbCrLf
                                Case 3
                                    SearchTextBox.Text += "Member Date of Birth : " + word + vbCrLf
                                Case 4
                                    SearchTextBox.Text += "Membership Date : " + word + vbCrLf
                                Case 5
                                    SearchTextBox.Text += "Member Gender : " + word + vbCrLf
                                Case 6
                                    SearchTextBox.Text += "Member Amount : " + word + vbCrLf
                                Case 7
                                    SearchTextBox.Text += "Member Completed : " + word + vbCrLf

                                Case Else


                            End Select

                            count = count + 1
                        Next

                    End If

                End While

            Else

                Found.Hide()
                NOT_FOUD.Show()
                Result.Text = " RESULT NOT  FOUND "

            End If
        End If


    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles Found.Click

    End Sub

    Private Sub BtnSearchExit_Click(sender As Object, e As EventArgs) Handles BtnSearchExit.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Managing_Motor_Racing.Show()
        Me.Hide()
    End Sub

    Private Sub Result_Click(sender As Object, e As EventArgs) Handles Result.Click

    End Sub
End Class